import SwiftUI

struct ShakingJarView: View {
    @Binding var intensity: Double
    @State private var isMovingRight = true
    
    var body: some View {
        Text("What are you grateful for today?").font(.title)
            .foregroundColor(.white)
            .fontWeight(.bold)
            .italic()
        Image("Jar") // Make sure to replace "Jar" with the actual image name
            .resizable()
            .scaledToFit()
            .rotationEffect(.degrees(intensity))
            .gesture(
                DragGesture()
                    .onChanged { value in
                        // You can add additional logic here if needed
                    }
                    .onEnded { _ in
                        // You can add additional logic here if needed
                    }
            )
            .onTapGesture {
                withAnimation(Animation.easeInOut(duration: 0.5).repeatForever()) {
                    intensity = isMovingRight ? -20 : 20
                    isMovingRight.toggle()
                }
            }
    }
}
